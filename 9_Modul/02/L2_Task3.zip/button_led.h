#ifndef BUTTON_LED_H
#define BUTTON_LED_H

#include <Arduino.h>

// Константы
const int button = 0;
const int led = 1;
const int currentB = 2;
const int lastB = 3;
const int ledBright = 4; // значение ШИМ на выводе соответствующего диода
const int step = 50;

// Массив состояний кнопок и светодиодов
extern int buttonLedState[6][5];

// Прототипы функций
int debounce(int last, int button);
void uplight(int led, int& ledBright);
void downlight(int led, int& ledBright);
void setupPins();
void loopControl();

#endif // BUTTON_LED_H